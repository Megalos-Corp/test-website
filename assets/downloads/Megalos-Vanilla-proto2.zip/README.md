# Megalos Vanilla Pack x16 0.0.1a

le mégalos vanilla comporte plusieurs addons créé par nesios.

### liste des addons :

- Nesios Stuff Addon 1.3.1
- Nesios Better Tweaks 0.9
- Nesios Food Pack 1.0
- Megalos Painting addon 1.4

### License

[GNU General Public License v3.0](https://choosealicense.com/licenses/gpl-3.0/)